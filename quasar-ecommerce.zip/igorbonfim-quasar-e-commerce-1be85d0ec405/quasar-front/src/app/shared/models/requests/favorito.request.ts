export class FavoritoRequest {
  public codProduto: number

  constructor(codigo: number) {
    this.codProduto = codigo;
  }
}
