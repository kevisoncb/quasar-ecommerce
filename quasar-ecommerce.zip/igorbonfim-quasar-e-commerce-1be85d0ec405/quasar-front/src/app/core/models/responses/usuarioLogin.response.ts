export class UsuarioLoginResponse {
    public sucesso!: boolean;
    public token!: string;
    public erro!: string;
    
}