import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendas-dados',
  templateUrl: './vendas-dados.component.html',
  styleUrls: ['./vendas-dados.component.css']
})
export class VendasDadosComponent implements OnInit {


  constructor() { }

  ngOnInit(): void {
  }

}
