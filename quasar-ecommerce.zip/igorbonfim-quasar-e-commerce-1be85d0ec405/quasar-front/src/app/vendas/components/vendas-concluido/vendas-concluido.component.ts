import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendas-concluido',
  templateUrl: './vendas-concluido.component.html',
  styleUrls: ['./vendas-concluido.component.css']
})
export class VendasConcluidoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
