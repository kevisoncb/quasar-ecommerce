export class ProdutoInserirResponse {
  public codigo!: number;
  public nome!: string;
}
