using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quasar.DataTransfer.Estoques.Responses
{
    public class EstoqueEditarResponse
    {
        public int Quantidade {get; set;}
    }
}