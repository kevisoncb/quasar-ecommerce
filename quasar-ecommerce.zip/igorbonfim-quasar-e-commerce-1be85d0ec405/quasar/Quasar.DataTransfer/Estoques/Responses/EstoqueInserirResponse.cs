using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quasar.DataTransfer.Estoques.Responses
{
    public class EstoqueInserirResponse
    {
        public int Codigo {get; set;}
        public int Quantidade {get; set;}
    }
}