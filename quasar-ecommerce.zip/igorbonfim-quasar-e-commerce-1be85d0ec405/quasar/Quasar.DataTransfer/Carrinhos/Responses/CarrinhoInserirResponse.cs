using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quasar.DataTransfer.Carrinhos.Responses
{
    public class CarrinhoInserirResponse
    {
        public int Codigo { get; set; }
    }
}