using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quasar.DataTransfer.Fornecedores.Responses
{
    public class FornecedorInserirResponse
    {
        public int Codigo { get; set; }
        public string Nome { get; set; }
    }
}