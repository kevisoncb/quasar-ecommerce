using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Quasar.DataTransfer.Categorias.Requests
{
    public class CategoriaInserirRequest
    {
        public string Nome {get; set;}
        public string Imagem {get; set;}
    }
}