using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentNHibernate.AspNetCore.Identity;

namespace Quasar.Dominio.Usuarios.Entidades
{
    public class Role : IdentityRole<string>
    {
        
    }
}