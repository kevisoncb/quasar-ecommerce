INSERT INTO FORNECEDOR(nome, razaoSocial, cnpj, ie)
VALUES (
    'CAR7',
    'CAR SEVEN DISTRIBUIDORA DE VIDROS',
    07239512000154,
    509892477
  ),
  #vidro 
  (
    'ParaShock',
    'ParaShock Industrias e Serviços LTDA',
    99508600000122,
    125005717
  ),
  #parachoque
  (
    'Retro Visor',
    'Distribuidora de Retrovisores',
    13266572000169,
    322370949
  ),
  #retrovisor
  (
    'Lanternas FX',
    'Lanternas FX Serviços e Distruibuição',
    85987299000172,
    898313821
  ),
  #lanternas
  (
    'FlashFarois',
    'FlashFarois Comércio e Industria LTDA',
    746564845979,
    407516646
  ),
  #farol
  (
    'Controle de Lanternagem',
    'Controle de Lanternagem Serviço',
    59450336000107,
    138338884
  ),
  #lanternas
  (
    'All Vidros',
    'All Vidros Industria e Serviços',
    27648252000188,
    127545760
  ),
  #vidro
  (
    'AutoFaróis',
    'AutoFaróis Distribuidora',
    82003008000176,
    244519021
  ),
  #farol
  (
    'Industria do Parachoque',
    'Industria do Parachoque Industria e Comércio',
    11280694000184,
    437341844
  ),
  #parachoque
  (
    'Lumus Retrovisores',
    'Distribuidora Lumus Retrovisores',
    38338393000110,
    309143233
  );
#retrovisor