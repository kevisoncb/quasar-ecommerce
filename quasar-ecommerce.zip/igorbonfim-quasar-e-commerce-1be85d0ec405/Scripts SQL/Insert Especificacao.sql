INSERT INTO Especificacao(codEspecificacao, posicao, cor, ano, veiculo) 
VALUES 
  (
    1,
    'Dianteira',
    'Verde Faixa Azul',
    '2021, 2022',
    'Civic'
  ),
#vidro parabrisa
  (
    2,
    'Dianteira',
    'Preto Liso',
    '2018, 2019',
    'Saveiro'
  ),
#parachoque
  (
    3,
    'Esquerdo (Motorista)',
    'Preto Liso',
    '2020, 2021',
    'Outlander'
  ),
#retrovisor
  (
    4,
    'Esquerdo',
    'Bicolor',
    '2021, 2022',
    'Airtrek'
  ),
#lanternas
  (
    5,
    'Direito',
    'Cromado',
    '2005, 2006',
    'Fit'
  ),
#farol
  (
    6,
    'Direito',
    'Verde Faixa Azul',
    '2002, 2003',
    'Escort'
  ),
#vidro janela
  (
    7,
    'Dianteira',
    'Preto',
    '2013, 2014',
    'Crossfox'
  ),
#parachoque grade
  (
    8,
    'Direito',
    'Preto',
    '2014, 2015',
    'Outlander'
  ),
#retrovisor
  (
    9,
    'Direito',
    'Bicolor',
    '2005, 2006',
    'Airtrek'
  ),
#lanternas
  (
    10,
    'Direito',
    'Cromado',
    '2020, 2021',
    'Compass'
  );
#farol diurno
