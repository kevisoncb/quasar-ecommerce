INSERT INTO formaPagamento(codFormaPagamento, descricao)
VALUES(1, 'Cartão de Crédito'),
(2, 'Boleto'),
(3, 'Pix');