INSERT INTO quasarecommerce.STATUSVENDA (descricao)
VALUES ("Aguardando pagamento"),
("Pagamento aprovado"),
("Pedido enviado"),
("Cancelado"),
("Pagamento recusado"),
("Pedido em separação"),
("Finalizado")
;